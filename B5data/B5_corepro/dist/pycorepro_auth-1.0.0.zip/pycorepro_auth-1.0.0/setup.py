#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/10/8 18:38
# @Author  : userzhang

from distutils.core import setup

setup(
    name="pycorepro_auth",
    version="1.0.0",
    py_modules=["auth_corepro"],
    author="userzhang",
    author_email="1409516337@qq.com",
    url="http://www.baidu.com",
    description="Device auth"

)